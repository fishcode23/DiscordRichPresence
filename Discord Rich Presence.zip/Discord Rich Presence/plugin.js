const RPC = require("discord-rpc")
const path = require("path")
const fs = require("fs")

exports.info = {
    description: "Adds Discord rich presence to FIDE.",
    author: "FishCode23",
    settings: "settings.json",
    minimum_version: "2022.2.2"
}

function getSettings(){
    return JSON.parse(fs.readFileSync(path.join(getPluginPath("Discord Rich Presence"), "settings.json")))
}

function getSetting(key, defaultValue=null){
    let val = getSettings()[key]

    if (val === undefined){
        val = defaultValue
    }

    return val
}

const rpc = new RPC.Client({transport: "ipc"})

function refreshPresence(){
    if (getSetting("enabled", false) == false){
        rpc.clearActivity()
        return
    }

    var editing = null

    files.forEach((f) => {
        if (f.editing == true){
            editing = f
            return true
        }
    })

    var path_ = ((working_dir == "") ? "No folder" : `In ${path.basename(working_dir)}`)

    if (editing !== null){
        rpc.request("SET_ACTIVITY", {
            pid: process.pid,
            activity: {
                details: `Editing ${path.basename(editing.path)}`,
                state: path_,
                assets: {
                    large_image: "logo",
                    large_text: `FIDE ${version}`
                },
                timestamps: {
                    start: startTime
                },
                instance: true
            }
        })
    } else {
        rpc.request("SET_ACTIVITY", {
            pid: process.pid,
            activity: {
                details: "Idling",
                state: path_,
                assets: {
                    large_image: "logo",
                    large_text: `FIDE ${version}`
                },
                timestamps: {
                    start: startTime
                },
                instance: true
            }
        })
    }
}

rpc.on("ready", () => {
    setInterval(() => {
        refreshPresence()
    }, 5000)
})

rpc.login({
    clientId: "972146994485289020"
})